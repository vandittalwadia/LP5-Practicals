#include <iostream>
#include <stdlib.h>
#include <omp.h>
using namespace std;

void bubble(int *, int);
void swap(int &, int &);

void mergesort(int a[], int i, int j);
void merge(int a[], int i1, int j1, int i2, int j2);

void bubble(int *a, int n)
{
    for (int i = 0; i < n; i++)
    {
        int first = i % 2;

#pragma omp parallel for shared(a, first)
        for (int j = first; j < n - 1; j += 2)
        {
            if (a[j] > a[j + 1])
            {
                swap(a[j], a[j + 1]);
            }
        }
    }
}

void swap(int &a, int &b)
{

    int test;
    test = a;
    a = b;
    b = test;
}

void mergesort(int a[], int i, int j)
{
    int mid;
    if (i < j)
    {
        mid = (i + j) / 2;
#pragma omp parallel sections
        {
#pragma omp section
            {
                mergesort(a, i, mid);
            }
#pragma omp section
            {
                mergesort(a, mid + 1, j);
            }
        }
        merge(a, i, mid, mid + 1, j);
    }
}
void merge(int a[], int i1, int j1, int i2, int j2)
{
    int temp[1000];
    int i, j, k;
    i = i1;
    j = i2;
    k = 0;
    while (i <= j1 && j <= j2)
    {
        if (a[i] < a[j])
        {
            temp[k++] = a[i++];
        }
        else
        {
            temp[k++] = a[j++];
        }
    }
    while (i <= j1)
    {
        temp[k++] = a[i++];
    }
    while (j <= j2)
    {
        temp[k++] = a[j++];
    }
    for (i = i1, j = 0; i <= j2; i++, j++)
    {
        a[i] = temp[j];
    }
}

int main()
{
    int *a1, n1;
    cout << "\n enter total no of elements for bubble sort=>";
    cin >> n1;
    a1 = new int[n1];
    cout << "\n enter elements for bubble sort=>";
    for (int i = 0; i < n1; i++)
    {
        cin >> a1[i];
    }

    bubble(a1, n1);

    cout << "\n sorted array is(Bubble sort)=>";
    for (int i = 0; i < n1; i++)
    {
        cout << a1[i] << endl;
    }

    int *a2, n2, i2;
    cout << "\n enter total no of elements for Merge sort=>";
    cin >> n2;
    a2 = new int[n2];
    cout << "\n enter elements(Merge Sort)=>";
    for (i2 = 0; i2 < n2; i2++)
    {
        cin >> a2[i2];
    }
    mergesort(a2, 0, n2 - 1);
    cout << "\n sorted array is(Merge Sort)=>";
    for (i2 = 0; i2 < n2; i2++)
    {
        cout << "\n"
             << a2[i2];
    }
    return 0;
}
